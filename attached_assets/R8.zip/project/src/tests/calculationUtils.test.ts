import { 
  calculateTotalAnnualHours,
  calculateBillableHours,
  calculateOnCosts,
  calculateChargeRate,
  initialCostConfig,
  initialWorkConfig,
  initialBillableOptions
} from '../utils/calculationUtils';
import { CostConfig, WorkConfig, BillableOptions } from '../types';

describe('Calculation Utilities', () => {
  describe('calculateTotalAnnualHours', () => {
    it('calculates total annual hours correctly', () => {
      const workConfig: WorkConfig = {
        hoursPerDay: 8,
        daysPerWeek: 5,
        weeksPerYear: 52,
        annualLeaveDays: 20,
        publicHolidays: 10,
        sickLeaveDays: 10,
        trainingWeeks: 4
      };
      
      // 8 hours * 5 days * 52 weeks = 2080 hours
      expect(calculateTotalAnnualHours(workConfig)).toBe(2080);
    });
    
    it('handles part-time days per week', () => {
      const workConfig: WorkConfig = {
        hoursPerDay: 8,
        daysPerWeek: 3,
        weeksPerYear: 52,
        annualLeaveDays: 20,
        publicHolidays: 10,
        sickLeaveDays: 10,
        trainingWeeks: 4
      };
      
      // 8 hours * 3 days * 52 weeks = 1248 hours
      expect(calculateTotalAnnualHours(workConfig)).toBe(1248);
    });
    
    it('handles part-time hours per day', () => {
      const workConfig: WorkConfig = {
        hoursPerDay: 4,
        daysPerWeek: 5,
        weeksPerYear: 52,
        annualLeaveDays: 20,
        publicHolidays: 10,
        sickLeaveDays: 10,
        trainingWeeks: 4
      };
      
      // 4 hours * 5 days * 52 weeks = 1040 hours
      expect(calculateTotalAnnualHours(workConfig)).toBe(1040);
    });
  });
  
  describe('calculateBillableHours', () => {
    const standardWorkConfig: WorkConfig = {
      hoursPerDay: 8,
      daysPerWeek: 5,
      weeksPerYear: 52,
      annualLeaveDays: 20,
      publicHolidays: 10,
      sickLeaveDays: 10,
      trainingWeeks: 4
    };
    
    const standardCostConfig: CostConfig = {
      ...initialCostConfig,
      adverseWeatherDays: 5
    };
    
    it('calculates billable hours with no inclusions', () => {
      const billableOptions: BillableOptions = {
        includeAnnualLeave: false,
        includePublicHolidays: false,
        includeSickLeave: false,
        includeTrainingTime: false,
        includeAdverseWeather: false
      };
      
      // Total work hours minus unbilled time
      // 8 hours * 5 days * 52 weeks = 2080 total hours
      
      // Unbilled days: annual leave (20) + public holidays (10) + sick leave (10) + adverse weather (5) = 45 days
      // Unbilled days to weeks: 45 / 5 = 9 weeks
      // Unbilled training weeks: 4 weeks
      // Total unbilled: 9 + 4 = 13 weeks
      // Billable weeks: 52 - 13 = 39 weeks
      // Billable hours: 8 hours * 5 days * 39 weeks = 1560 hours
      
      expect(calculateBillableHours(standardWorkConfig, standardCostConfig, billableOptions)).toBe(1560);
    });
    
    it('includes annual leave in billable hours when specified', () => {
      const billableOptions: BillableOptions = {
        includeAnnualLeave: true,
        includePublicHolidays: false,
        includeSickLeave: false,
        includeTrainingTime: false,
        includeAdverseWeather: false
      };
      
      // Annual leave days: 20 days = 4 weeks
      // Should now include those 4 weeks in billable time
      // Billable weeks: 39 + 4 = 43 weeks
      // Billable hours: 8 hours * 5 days * 43 weeks = 1720 hours
      
      expect(calculateBillableHours(standardWorkConfig, standardCostConfig, billableOptions)).toBe(1720);
    });
    
    it('includes all options in billable hours when specified', () => {
      const billableOptions: BillableOptions = {
        includeAnnualLeave: true,
        includePublicHolidays: true,
        includeSickLeave: true,
        includeTrainingTime: true,
        includeAdverseWeather: true
      };
      
      // All time is now billable
      // Billable hours: 8 hours * 5 days * 52 weeks = 2080 hours
      
      expect(calculateBillableHours(standardWorkConfig, standardCostConfig, billableOptions)).toBe(2080);
    });
  });
  
  describe('calculateOnCosts', () => {
    it('calculates oncosts correctly', () => {
      const payRate = 25.00;
      const totalHours = 2080; // 40 hours/week for 52 weeks
      const costConfig: CostConfig = {
        superRate: 0.115,
        wcRate: 0.05,
        payrollTaxRate: 0.05,
        leaveLoading: 0.175,
        studyCost: 1000,
        ppeCost: 500,
        adminRate: 0.15,
        defaultMargin: 0.2,
        adverseWeatherDays: 5
      };
      
      const baseWage = payRate * totalHours; // $52,000
      const annualLeaveHours = Math.min(totalHours, 152); // 152 hours (4 weeks at 38 hours)
      
      const expectedOnCosts = {
        superannuation: baseWage * 0.115, // $5,980
        workersComp: baseWage * 0.05, // $2,600
        payrollTax: baseWage * 0.05, // $2,600
        leaveLoading: payRate * annualLeaveHours * 0.175, // $665
        studyCost: 1000,
        ppeCost: 500,
        adminCost: baseWage * 0.15, // $7,800
      };
      
      const result = calculateOnCosts(payRate, totalHours, costConfig);
      
      expect(result.superannuation).toBeCloseTo(expectedOnCosts.superannuation);
      expect(result.workersComp).toBeCloseTo(expectedOnCosts.workersComp);
      expect(result.payrollTax).toBeCloseTo(expectedOnCosts.payrollTax);
      expect(result.leaveLoading).toBeCloseTo(expectedOnCosts.leaveLoading);
      expect(result.studyCost).toBe(expectedOnCosts.studyCost);
      expect(result.ppeCost).toBe(expectedOnCosts.ppeCost);
      expect(result.adminCost).toBeCloseTo(expectedOnCosts.adminCost);
    });
    
    it('caps leave loading at 4 weeks', () => {
      const payRate = 25.00;
      const totalHours = 4000; // Very high hours, should be capped
      const costConfig: CostConfig = { ...initialCostConfig };
      
      const result = calculateOnCosts(payRate, totalHours, costConfig);
      
      // Leave loading should be capped at 152 hours (4 weeks)
      const expectedLeaveLoading = payRate * 152 * costConfig.leaveLoading;
      expect(result.leaveLoading).toBeCloseTo(expectedLeaveLoading);
    });
  });
  
  describe('calculateChargeRate', () => {
    it('calculates the complete charge rate correctly', () => {
      const payRate = 25.00;
      const workConfig: WorkConfig = { ...initialWorkConfig };
      const costConfig: CostConfig = { ...initialCostConfig };
      const billableOptions: BillableOptions = { ...initialBillableOptions };
      
      const result = calculateChargeRate(payRate, workConfig, costConfig, billableOptions);
      
      // Check that all expected properties are defined
      expect(result.payRate).toBe(payRate);
      expect(result.totalHours).toBeGreaterThan(0);
      expect(result.billableHours).toBeGreaterThan(0);
      expect(result.billableHours).toBeLessThanOrEqual(result.totalHours);
      expect(result.baseWage).toBeGreaterThan(0);
      expect(result.oncosts).toBeDefined();
      expect(result.totalCost).toBeGreaterThan(result.baseWage);
      expect(result.costPerHour).toBeGreaterThan(payRate);
      expect(result.chargeRate).toBeGreaterThan(result.costPerHour);
      
      // Verify the charge rate calculation
      const margin = costConfig.defaultMargin;
      const expectedChargeRate = result.costPerHour * (1 + margin);
      expect(result.chargeRate).toBeCloseTo(expectedChargeRate);
    });
    
    it('applies a custom margin when provided', () => {
      const payRate = 25.00;
      const workConfig: WorkConfig = { ...initialWorkConfig };
      const costConfig: CostConfig = { ...initialCostConfig };
      const billableOptions: BillableOptions = { ...initialBillableOptions };
      const customMargin = 0.25; // 25% 
      
      const result = calculateChargeRate(payRate, workConfig, costConfig, billableOptions, customMargin);
      
      // Verify the custom margin is applied
      expect(result.chargeRate).toBeCloseTo(result.costPerHour * 1.25);
    });
  });
});