import { 
  fetchAwardTemplates, 
  getApprenticeRateForYear, 
  saveAwardTemplatesToLocalStorage,
  loadAwardTemplatesFromLocalStorage,
  createAwardTemplate,
  updateAwardTemplate,
  deleteAwardTemplate,
  fetchAwardTemplatesByYear
} from '../services/awardTemplateService';
import { ApprenticeYear } from '../types';

// Mock the local storage
const mockLocalStorage = (() => {
  let store: Record<string, string> = {};
  
  return {
    getItem: jest.fn((key: string) => store[key] || null),
    setItem: jest.fn((key: string, value: string) => {
      store[key] = value.toString();
    }),
    removeItem: jest.fn((key: string) => {
      delete store[key];
    }),
    clear: jest.fn(() => {
      store = {};
    }),
    getAllItems: () => store
  };
})();

// Mock Supabase client
jest.mock('../services/supabaseClient', () => ({
  supabase: {
    auth: {
      getSession: jest.fn().mockResolvedValue({ data: { session: null } })
    },
    from: jest.fn().mockReturnValue({
      select: jest.fn().mockReturnThis(),
      insert: jest.fn().mockReturnThis(),
      update: jest.fn().mockReturnThis(),
      delete: jest.fn().mockReturnThis(),
      eq: jest.fn().mockReturnThis(),
      order: jest.fn().mockReturnThis(),
      single: jest.fn().mockReturnThis(),
      then: jest.fn().mockImplementation(cb => cb({ data: null, error: { message: 'permission denied for schema public' } }))
    })
  }
}));

describe('Award Template Service', () => {
  // Replace localStorage with mock
  Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });
  
  beforeEach(() => {
    mockLocalStorage.clear();
  });

  describe('saveAwardTemplatesToLocalStorage and loadAwardTemplatesFromLocalStorage', () => {
    it('should save and load templates from localStorage', async () => {
      const templates = [
        {
          id: '1',
          code: 'TEST001',
          name: 'Test Award 1',
          rates: {
            year1: 20,
            year2: 25,
            year3: 30,
            year4: 35,
            qualified: 40
          },
          calendar_year: 2025,
          updated_at: new Date().toISOString()
        }
      ];
      
      saveAwardTemplatesToLocalStorage(templates);
      
      // Check if data was saved to localStorage
      expect(mockLocalStorage.getItem('r8calculator_award_templates')).not.toBeNull();
      
      // Load templates and verify
      const loadedTemplates = await loadAwardTemplatesFromLocalStorage();
      expect(loadedTemplates).toHaveLength(1);
      expect(loadedTemplates[0].code).toBe('TEST001');
      expect(loadedTemplates[0].rates.year1).toBe(20);
      expect(loadedTemplates[0].calendar_year).toBe(2025);
    });
    
    it('should return default templates if localStorage is empty', async () => {
      // Ensure localStorage is empty
      mockLocalStorage.clear();
      
      // Load templates
      const templates = await loadAwardTemplatesFromLocalStorage();
      
      // Should return default templates
      expect(templates.length).toBeGreaterThan(0);
      expect(templates[0].code).toBe('MA000020'); // First default award
      
      // Should save default templates to localStorage
      expect(mockLocalStorage.setItem).toHaveBeenCalled();
    });
  });
  
  describe('getApprenticeRateForYear', () => {
    const award = {
      id: '1',
      code: 'TEST001',
      name: 'Test Award',
      rates: {
        year1: 20.50,
        year2: 25.75,
        year3: 30.25,
        year4: 35.50,
        qualified: 45.00
      },
      calendar_year: 2025,
      updated_at: new Date().toISOString()
    };
    
    it('returns the correct rate for each year', () => {
      expect(getApprenticeRateForYear(award, 1 as ApprenticeYear)).toBe(20.50);
      expect(getApprenticeRateForYear(award, 2 as ApprenticeYear)).toBe(25.75);
      expect(getApprenticeRateForYear(award, 3 as ApprenticeYear)).toBe(30.25);
      expect(getApprenticeRateForYear(award, 4 as ApprenticeYear)).toBe(35.50);
    });
    
    it('returns null for invalid year or award', () => {
      expect(getApprenticeRateForYear(award, 5 as unknown as ApprenticeYear)).toBeNull();
      expect(getApprenticeRateForYear(null as any, 1 as ApprenticeYear)).toBeNull();
      
      const awardWithoutRates = { ...award, rates: undefined };
      expect(getApprenticeRateForYear(awardWithoutRates as any, 1 as ApprenticeYear)).toBeNull();
    });
  });
  
  describe('CRUD operations', () => {
    const newAwardTemplate = {
      code: 'NEW001',
      name: 'New Test Award',
      rates: {
        year1: 21.00,
        year2: 26.00,
        year3: 31.00,
        year4: 36.00,
        qualified: 45.00
      },
      industry: 'Test',
      calendar_year: 2025
    };
    
    it('should create a new award template in local storage', async () => {
      const result = await createAwardTemplate(newAwardTemplate);
      
      expect(result.award).not.toBeNull();
      expect(result.isLocal).toBe(true);
      expect(result.error).toBeNull();
      
      if (result.award) {
        expect(result.award.id).toContain('local-');
        expect(result.award.name).toBe(newAwardTemplate.name);
        expect(result.award.calendar_year).toBe(2025);
        
        // Verify it was saved to localStorage
        const templates = await loadAwardTemplatesFromLocalStorage();
        expect(templates.find(t => t.name === newAwardTemplate.name)).toBeDefined();
      }
    });
    
    it('should update an existing template in local storage', async () => {
      // First create a template
      const createResult = await createAwardTemplate(newAwardTemplate);
      expect(createResult.award).not.toBeNull();
      
      if (createResult.award) {
        const templateId = createResult.award.id;
        const updates = {
          name: 'Updated Award Name',
          rates: {
            ...createResult.award.rates,
            year1: 22.00
          },
          calendar_year: 2026
        };
        
        const updateResult = await updateAwardTemplate(templateId, updates);
        
        expect(updateResult.award).not.toBeNull();
        expect(updateResult.isLocal).toBe(true);
        expect(updateResult.error).toBeNull();
        
        if (updateResult.award) {
          expect(updateResult.award.id).toBe(templateId);
          expect(updateResult.award.name).toBe('Updated Award Name');
          expect(updateResult.award.rates.year1).toBe(22.00);
          expect(updateResult.award.calendar_year).toBe(2026);
          
          // Verify it was updated in localStorage
          const templates = await loadAwardTemplatesFromLocalStorage();
          const updatedTemplate = templates.find(t => t.id === templateId);
          expect(updatedTemplate).toBeDefined();
          expect(updatedTemplate?.name).toBe('Updated Award Name');
          expect(updatedTemplate?.calendar_year).toBe(2026);
        }
      }
    });
    
    it('should delete an existing template from local storage', async () => {
      // First create a template
      const createResult = await createAwardTemplate(newAwardTemplate);
      expect(createResult.award).not.toBeNull();
      
      if (createResult.award) {
        const templateId = createResult.award.id;
        
        // Verify it exists in localStorage
        let templates = await loadAwardTemplatesFromLocalStorage();
        expect(templates.find(t => t.id === templateId)).toBeDefined();
        
        // Delete the template
        const deleteResult = await deleteAwardTemplate(templateId);
        expect(deleteResult.success).toBe(true);
        expect(deleteResult.isLocal).toBe(true);
        expect(deleteResult.error).toBeNull();
        
        // Verify it was removed from localStorage
        templates = await loadAwardTemplatesFromLocalStorage();
        expect(templates.find(t => t.id === templateId)).toBeUndefined();
      }
    });
  });
  
  describe('fetchAwardTemplates', () => {
    it('should fetch templates from localStorage when not authenticated', async () => {
      // Save some templates to localStorage
      const templates = [
        {
          id: 'local-1',
          code: 'LOCAL001',
          name: 'Local Award 1',
          rates: {
            year1: 20,
            year2: 25,
            year3: 30,
            year4: 35,
            qualified: 40
          },
          calendar_year: 2025,
          updated_at: new Date().toISOString()
        }
      ];
      saveAwardTemplatesToLocalStorage(templates);
      
      // Fetch templates
      const fetchedTemplates = await fetchAwardTemplates();
      
      expect(fetchedTemplates).toHaveLength(1);
      expect(fetchedTemplates[0].code).toBe('LOCAL001');
      expect(fetchedTemplates[0].calendar_year).toBe(2025);
    });
  });

  describe('fetchAwardTemplatesByYear', () => {
    it('should fetch templates for a specific year', async () => {
      // Save templates with different years to localStorage
      const templates = [
        {
          id: 'local-1',
          code: 'LOCAL001',
          name: 'Local Award 2025',
          rates: {
            year1: 20,
            year2: 25,
            year3: 30,
            year4: 35,
            qualified: 40
          },
          calendar_year: 2025,
          updated_at: new Date().toISOString()
        },
        {
          id: 'local-2',
          code: 'LOCAL002',
          name: 'Local Award 2024',
          rates: {
            year1: 19,
            year2: 24,
            year3: 29,
            year4: 34,
            qualified: 39
          },
          calendar_year: 2024,
          updated_at: new Date().toISOString()
        }
      ];
      saveAwardTemplatesToLocalStorage(templates);
      
      // Fetch templates for 2025
      const templates2025 = await fetchAwardTemplatesByYear(2025);
      expect(templates2025.length).toBeGreaterThan(0);
      expect(templates2025.find(t => t.calendar_year === 2025)).toBeDefined();
      
      // For a year with no templates, should return most recent year's templates
      const templates2026 = await fetchAwardTemplatesByYear(2026);
      expect(templates2026.length).toBeGreaterThan(0);
    });
  });
});