import { exportApprenticeData, importApprenticeData } from '../services/exportImportService';
import { ApprenticeProfile, ApprenticeYear } from '../types';
import { initialCostConfig, initialWorkConfig, initialBillableOptions } from '../utils/calculationUtils';

// Mock file-saver module
jest.mock('file-saver', () => ({
  saveAs: jest.fn()
}));

describe('Export/Import Service', () => {
  // Valid test apprentice profile
  const validApprentice: ApprenticeProfile = {
    id: 'test-id-1',
    name: 'Test Apprentice',
    year: 2 as ApprenticeYear,
    basePayRate: 25.75,
    customSettings: false,
    costConfig: { ...initialCostConfig },
    workConfig: { ...initialWorkConfig },
    billableOptions: { ...initialBillableOptions },
    createdAt: new Date(),
    updatedAt: new Date()
  };
  
  // Invalid test apprentice profiles
  const invalidApprenticeNoId = { ...validApprentice, id: undefined } as unknown as ApprenticeProfile;
  const invalidApprenticeNoName = { ...validApprentice, name: '' } as ApprenticeProfile;
  const invalidApprenticeInvalidYear = { ...validApprentice, year: 5 } as unknown as ApprenticeProfile;
  
  describe('exportApprenticeData', () => {
    it('returns true when export is successful', () => {
      const result = exportApprenticeData([validApprentice]);
      expect(result).toBe(true);
    });
    
    it('validates apprentice data before export', () => {
      // No ID
      expect(() => exportApprenticeData([invalidApprenticeNoId])).toThrow();
      
      // No name
      expect(() => exportApprenticeData([invalidApprenticeNoName])).toThrow();
      
      // Invalid year
      expect(() => exportApprenticeData([invalidApprenticeInvalidYear])).toThrow();
      
      // Mix of valid and invalid
      expect(() => exportApprenticeData([validApprentice, invalidApprenticeNoId])).toThrow();
    });
  });

  describe('importApprenticeData', () => {
    // Mock implementation for FileReader
    let fileReaderInstance: any;
    let originalFileReader: any;
    
    beforeEach(() => {
      fileReaderInstance = {
        onload: null,
        onerror: null,
        readAsText: jest.fn().mockImplementation(function(this: any) {
          this.onload({ target: { result: '' } });
        })
      };
      
      originalFileReader = global.FileReader;
      global.FileReader = jest.fn(() => fileReaderInstance) as any;
    });
    
    afterEach(() => {
      global.FileReader = originalFileReader;
    });
    
    it('rejects when file cannot be read', async () => {
      fileReaderInstance.readAsText = jest.fn().mockImplementation(function(this: any) {
        this.onerror(new Error('File read error'));
      });
      
      const file = new File([''], 'test.json', { type: 'application/json' });
      await expect(importApprenticeData(file)).rejects.toThrow();
    });
    
    it('rejects when file is not valid JSON', async () => {
      fileReaderInstance.readAsText = jest.fn().mockImplementation(function(this: any) {
        this.onload({ target: { result: 'not-json' } });
      });
      
      const file = new File(['not-json'], 'test.json', { type: 'application/json' });
      await expect(importApprenticeData(file)).rejects.toThrow('Invalid JSON format');
    });
    
    it('rejects when JSON data is missing apprentices array', async () => {
      const invalidJsonData = JSON.stringify({ 
        exportDate: new Date().toISOString(),
        version: '1.0.0'
        // Missing apprentices array
      });
      
      fileReaderInstance.readAsText = jest.fn().mockImplementation(function(this: any) {
        this.onload({ target: { result: invalidJsonData } });
      });
      
      const file = new File([invalidJsonData], 'test.json', { type: 'application/json' });
      await expect(importApprenticeData(file)).rejects.toThrow('Invalid import data structure');
    });
    
    it('validates apprentice data during import', async () => {
      const invalidData = JSON.stringify({ 
        apprentices: [invalidApprenticeNoId],
        exportDate: new Date().toISOString(),
        version: '1.0.0'
      });
      
      fileReaderInstance.readAsText = jest.fn().mockImplementation(function(this: any) {
        this.onload({ target: { result: invalidData } });
      });
      
      const file = new File([invalidData], 'test.json', { type: 'application/json' });
      await expect(importApprenticeData(file)).rejects.toThrow();
    });
    
    it('imports valid data correctly', async () => {
      const exportedData = {
        apprentices: [validApprentice],
        exportDate: new Date().toISOString(),
        version: '1.0.0'
      };
      
      fileReaderInstance.readAsText = jest.fn().mockImplementation(function(this: any) {
        this.onload({ target: { result: JSON.stringify(exportedData) } });
      });
      
      const file = new File(['{}'], 'test.json', { type: 'application/json' });
      const result = await importApprenticeData(file);
      
      expect(result.length).toBe(1);
      expect(result[0].id).toBe(validApprentice.id);
      expect(result[0].name).toBe(validApprentice.name);
      // Verify dates were converted from strings back to Date objects
      expect(result[0].createdAt).toBeInstanceOf(Date);
      expect(result[0].updatedAt).toBeInstanceOf(Date);
    });
  });
});