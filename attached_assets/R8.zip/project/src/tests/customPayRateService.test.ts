import { 
  fetchCustomPayRates,
  getPayRateForYear,
  saveToLocalStorage,
  createCustomPayRate,
  updateCustomPayRate,
  deleteCustomPayRate
} from '../services/customPayRateService';
import { ApprenticeYear } from '../types';

// Mock localStorage
const mockLocalStorage = (() => {
  let store: Record<string, string> = {};
  
  return {
    getItem: jest.fn((key: string) => store[key] || null),
    setItem: jest.fn((key: string, value: string) => {
      store[key] = value.toString();
    }),
    removeItem: jest.fn((key: string) => {
      delete store[key];
    }),
    clear: jest.fn(() => {
      store = {};
    })
  };
})();

// Mock Supabase client
jest.mock('../services/supabaseClient', () => ({
  supabase: {
    auth: {
      getSession: jest.fn().mockResolvedValue({ data: { session: null } })
    },
    from: jest.fn().mockReturnValue({
      select: jest.fn().mockReturnThis(),
      insert: jest.fn().mockReturnThis(),
      update: jest.fn().mockReturnThis(),
      delete: jest.fn().mockReturnThis(),
      eq: jest.fn().mockReturnThis(),
      order: jest.fn().mockReturnThis(),
      single: jest.fn().mockReturnThis(),
      then: jest.fn().mockImplementation(cb => cb({ data: null, error: { message: 'permission denied for schema public' } }))
    })
  }
}));

describe('Custom Pay Rate Service', () => {
  // Replace localStorage with mock
  Object.defineProperty(window, 'localStorage', { value: mockLocalStorage });
  
  beforeEach(() => {
    mockLocalStorage.clear();
  });

  describe('saveToLocalStorage', () => {
    it('should save presets to localStorage', () => {
      const presets = [
        {
          id: 'preset-1',
          name: 'Test Preset',
          year1_rate: 20.5,
          year2_rate: 25.5,
          year3_rate: 30.5,
          year4_rate: 35.5,
          calendar_year: 2025
        }
      ];
      
      saveToLocalStorage(presets);
      
      // Check if data was saved to localStorage
      expect(mockLocalStorage.setItem).toHaveBeenCalledWith(
        'r8calculator_pay_rate_presets',
        JSON.stringify(presets)
      );
    });
  });

  describe('getPayRateForYear', () => {
    const preset = {
      id: 'preset-1',
      name: 'Test Preset',
      year1_rate: 20.5,
      year2_rate: 25.5,
      year3_rate: 30.5,
      year4_rate: 35.5,
      calendar_year: 2025
    };
    
    it('returns the correct rate for each year', () => {
      expect(getPayRateForYear(preset, 1 as ApprenticeYear)).toBe(20.5);
      expect(getPayRateForYear(preset, 2 as ApprenticeYear)).toBe(25.5);
      expect(getPayRateForYear(preset, 3 as ApprenticeYear)).toBe(30.5);
      expect(getPayRateForYear(preset, 4 as ApprenticeYear)).toBe(35.5);
    });
    
    it('returns 0 for invalid year', () => {
      expect(getPayRateForYear(preset, 5 as unknown as ApprenticeYear)).toBe(0);
    });
  });

  describe('CRUD operations', () => {
    // Setup localStorage with initial data
    beforeEach(() => {
      const initialPresets = [
        {
          id: 'preset-1',
          name: 'Initial Preset',
          year1_rate: 20,
          year2_rate: 25,
          year3_rate: 30,
          year4_rate: 35,
          calendar_year: 2025
        }
      ];
      
      mockLocalStorage.setItem('r8calculator_pay_rate_presets', JSON.stringify(initialPresets));
    });
    
    it('should create a new custom pay rate', async () => {
      const newPreset = {
        name: 'New Preset',
        year1_rate: 21,
        year2_rate: 26,
        year3_rate: 31,
        year4_rate: 36,
        calendar_year: 2025
      };
      
      const result = await createCustomPayRate(newPreset);
      
      expect(result.preset).not.toBeNull();
      expect(result.isLocal).toBe(true);
      expect(result.error).toBeNull();
      
      if (result.preset) {
        expect(result.preset.id).toContain('local-');
        expect(result.preset.name).toBe(newPreset.name);
        expect(result.preset.calendar_year).toBe(2025);
      }
      
      // Verify localStorage was updated
      const storage = mockLocalStorage.getItem('r8calculator_pay_rate_presets');
      expect(storage).not.toBeNull();
      
      if (storage) {
        const presets = JSON.parse(storage);
        expect(presets.length).toBe(2); // Initial + new preset
        expect(presets.some((p: any) => p.name === newPreset.name)).toBe(true);
      }
    });
    
    it('should update an existing custom pay rate', async () => {
      // First fetch the presets to get the IDs
      const { presets } = await fetchCustomPayRates();
      expect(presets.length).toBeGreaterThan(0);
      
      const presetToUpdate = presets[0];
      const updates = {
        name: 'Updated Preset Name',
        year1_rate: 22,
        calendar_year: 2026
      };
      
      const result = await updateCustomPayRate(presetToUpdate.id || '', updates);
      
      expect(result.preset).not.toBeNull();
      expect(result.isLocal).toBe(true);
      expect(result.error).toBeNull();
      
      if (result.preset) {
        expect(result.preset.name).toBe(updates.name);
        expect(result.preset.year1_rate).toBe(updates.year1_rate);
        expect(result.preset.calendar_year).toBe(2026);
        // Unchanged fields should remain the same
        expect(result.preset.year2_rate).toBe(presetToUpdate.year2_rate);
      }
      
      // Fetch presets again to verify update
      const { presets: updatedPresets } = await fetchCustomPayRates();
      const updatedPreset = updatedPresets.find(p => p.id === presetToUpdate.id);
      expect(updatedPreset).toBeDefined();
      expect(updatedPreset?.name).toBe(updates.name);
      expect(updatedPreset?.calendar_year).toBe(2026);
    });
    
    it('should delete a custom pay rate', async () => {
      // First fetch the presets to get the IDs
      const { presets } = await fetchCustomPayRates();
      expect(presets.length).toBeGreaterThan(0);
      
      const presetToDelete = presets[0];
      const result = await deleteCustomPayRate(presetToDelete.id || '');
      
      expect(result.success).toBe(true);
      expect(result.isLocal).toBe(true);
      expect(result.error).toBeNull();
      
      // Fetch presets again to verify deletion
      const { presets: updatedPresets } = await fetchCustomPayRates();
      expect(updatedPresets.length).toBe(0);
    });
  });

  describe('fetchCustomPayRates', () => {
    it('should fetch presets from localStorage when not authenticated', async () => {
      const testPresets = [
        {
          id: 'preset-1',
          name: 'Test Preset 1',
          year1_rate: 20,
          year2_rate: 25,
          year3_rate: 30,
          year4_rate: 35,
          calendar_year: 2025
        },
        {
          id: 'preset-2',
          name: 'Test Preset 2',
          year1_rate: 22,
          year2_rate: 27,
          year3_rate: 32,
          year4_rate: 37,
          calendar_year: 2024
        }
      ];
      
      mockLocalStorage.setItem('r8calculator_pay_rate_presets', JSON.stringify(testPresets));
      
      const { presets, isLocal } = await fetchCustomPayRates();
      
      expect(isLocal).toBe(true);
      expect(presets.length).toBe(2);
      expect(presets[0].name).toBe('Test Preset 1');
      expect(presets[0].calendar_year).toBe(2025);
      expect(presets[1].name).toBe('Test Preset 2');
      expect(presets[1].calendar_year).toBe(2024);
    });
    
    it('should use default presets if localStorage is empty', async () => {
      // Ensure localStorage is empty
      mockLocalStorage.clear();
      
      const { presets, isLocal } = await fetchCustomPayRates();
      
      expect(isLocal).toBe(true);
      expect(presets.length).toBeGreaterThan(0);
      // Default presets should have this year's calendar year
      expect(presets[0].calendar_year).toBe(new Date().getFullYear());
    });
  });
});