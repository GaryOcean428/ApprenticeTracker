export interface CostConfig {
  superRate: number;        // e.g., 0.115 for 11.5%
  wcRate: number;           // workers' compensation rate
  payrollTaxRate: number;   // payroll tax rate
  leaveLoading: number;     // leave loading percentage
  studyCost: number;        // annual study cost
  ppeCost: number;          // annual protective clothing cost
  adminRate: number;        // administration overhead rate
  defaultMargin: number;    // default profit margin
  adverseWeatherDays: number; // days lost to adverse weather
}

export interface WorkConfig {
  hoursPerDay: number;
  daysPerWeek: number;
  weeksPerYear: number;
  annualLeaveDays: number;
  publicHolidays: number;
  sickLeaveDays: number;
  trainingWeeks: number;
}

export interface BillableOptions {
  includeAnnualLeave: boolean;
  includePublicHolidays: boolean;
  includeSickLeave: boolean;
  includeTrainingTime: boolean;
  includeAdverseWeather: boolean;
}

export interface OnCosts {
  superannuation: number;
  workersComp: number;
  payrollTax: number;
  leaveLoading: number;
  studyCost: number;
  ppeCost: number;
  adminCost: number;
}

export interface CalculationResult {
  payRate: number;
  totalHours: number;
  billableHours: number;
  baseWage: number;
  oncosts: OnCosts;
  totalCost: number;
  costPerHour: number;
  chargeRate: number;
}

export type ApprenticeYear = 1 | 2 | 3 | 4;

export interface ApprenticeProfile {
  id: string;
  name: string;
  year: ApprenticeYear;
  basePayRate: number;
  awardCode?: string;
  awardId?: number;
  customSettings: boolean;
  costConfig: CostConfig;
  workConfig: WorkConfig;
  billableOptions: BillableOptions;
  result?: CalculationResult;
  createdAt: Date;
  updatedAt: Date;
  calendar_year?: number; // Calendar year the rates apply to
  financial_year?: number; // Financial year the rates apply to (July-June)
}

export interface Award {
  id: string;
  code: string;
  name: string;
  rates: {
    year1: number;
    year2: number;
    year3: number;
    year4: number;
    qualified: number;
  };
  industry: string;
  updatedAt: Date;
  calendar_year?: number; // Calendar year the rates apply to
  financial_year?: number; // Financial year the rates apply to (July-June)
}

export interface SavedCalculation {
  id: string;
  name: string;
  description?: string;
  apprentices: ApprenticeProfile[];
  createdAt: Date;
  updatedAt: Date;
  userId?: string;
  isTemplate: boolean;
  industry?: string;
  tags?: string[];
}

export interface FairWorkAward {
  award_fixed_id: number;
  code: string;
  name: string;
  published_year: number;
}

export interface ClassificationRate {
  classification_fixed_id: number;
  classification: string;
  hourlyRate: number;
  weeklyRate: number;
  level: number;
  year?: ApprenticeYear;
  calendar_year?: number; // Calendar year the rate applies to
  financial_year?: number; // Financial year the rate applies to (July-June)
}

// New interfaces for award flexibility
export interface AwardTemplate {
  id: string;
  code: string;
  name: string;
  rates: {
    year1: number;
    year2: number;
    year3: number;
    year4: number;
    qualified: number;
  };
  industry?: string;
  sector?: string; // e.g., "residential", "commercial", "civil"
  updated_at: string;
  calendar_year?: number; // Calendar year the rates apply to
  financial_year?: number; // Financial year the rates apply to
  is_adult?: boolean; // Whether these are adult apprentice rates
  has_completed_year12?: boolean; // Whether these rates apply to apprentices who completed year 12
}

export interface ApprenticeType {
  id: string;
  name: string; // e.g., "Junior Apprentice", "Adult Apprentice"
  description?: string;
  min_age?: number; // Minimum age for this type (e.g., 21 for adult apprentices)
  training_weeks?: number; // Default training weeks for this type
}

export interface IndustrySector {
  id: string;
  name: string; // e.g., "Residential", "Commercial", "Civil"
  description?: string;
  industry: string; // Parent industry
}