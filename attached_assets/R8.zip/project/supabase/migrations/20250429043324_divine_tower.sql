/*
  # Fix API keys table policies

  1. Changes
    - Drop existing duplicate policies
    - Re-create policies with checks to prevent duplicates

  2. Purpose
    - Fix errors when applying migrations due to duplicate policies
    - Ensure proper access control to API keys
*/

-- Check if the table exists before trying to modify it
DO $$ 
BEGIN
  IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'api_keys') THEN
    -- Drop policies if they exist to avoid duplication errors
    DROP POLICY IF EXISTS "api_keys_service_role_all" ON public.api_keys;
    DROP POLICY IF EXISTS "api_keys_anon_read" ON public.api_keys;
    DROP POLICY IF EXISTS "api_keys_auth_read" ON public.api_keys;
    DROP POLICY IF EXISTS "super_admin_access_ai_keys" ON public.api_keys;
    
    -- Re-create policies
    CREATE POLICY "api_keys_service_role_all"
      ON public.api_keys
      FOR ALL
      TO service_role
      USING (true);
      
    CREATE POLICY "api_keys_anon_read"
      ON public.api_keys
      FOR SELECT
      TO anon
      USING (key_name = 'FAIRWORK_API_KEY');
      
    CREATE POLICY "api_keys_auth_read"
      ON public.api_keys
      FOR SELECT
      TO authenticated
      USING (key_name = 'FAIRWORK_API_KEY');
      
    -- Make sure the FAIRWORK_API_KEY exists
    INSERT INTO public.api_keys (key_name, key_value)
    VALUES ('FAIRWORK_API_KEY', '270281931d6941f6a4738f6a8123ae47')
    ON CONFLICT (key_name) 
    DO UPDATE SET key_value = EXCLUDED.key_value, updated_at = now();
  END IF;
END $$;