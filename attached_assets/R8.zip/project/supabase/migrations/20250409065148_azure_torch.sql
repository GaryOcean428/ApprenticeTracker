/*
  # Create Apprentice Profiles System

  1. New Tables
    - `apprentice_profiles`
      - `id` (uuid, primary key)
      - `name` (text, name of the apprentice)
      - `user_id` (uuid, foreign key to auth.users)
      - `year` (integer, apprenticeship year 1-4)
      - `base_pay_rate` (numeric, hourly pay rate)
      - `award_id` (uuid, optional foreign key to awards)
      - `cost_config` (jsonb, cost configuration object)
      - `work_config` (jsonb, work hours configuration object)
      - `billable_options` (jsonb, billable options configuration)
      - `custom_settings` (boolean, whether using custom settings or defaults)
      - `created_at` (timestamp with time zone, creation time)
      - `updated_at` (timestamp with time zone, last update time)
    
  2. Security
    - Enable RLS on `apprentice_profiles` table
    - Add policy for authenticated users to manage their own profiles
    - Add policy for reading public profiles
*/

CREATE TABLE IF NOT EXISTS apprentice_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  user_id uuid REFERENCES auth.users,
  year integer NOT NULL CHECK (year BETWEEN 1 AND 4),
  base_pay_rate numeric(10,2) NOT NULL,
  award_id uuid,
  cost_config jsonb NOT NULL DEFAULT '{}'::jsonb,
  work_config jsonb NOT NULL DEFAULT '{}'::jsonb,
  billable_options jsonb NOT NULL DEFAULT '{}'::jsonb,
  custom_settings boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE apprentice_profiles ENABLE ROW LEVEL SECURITY;

-- Create policy for users to manage their own profiles
CREATE POLICY "Users can manage their own apprentice profiles"
  ON apprentice_profiles
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create a trigger to update the updated_at column
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_timestamp
BEFORE UPDATE ON apprentice_profiles
FOR EACH ROW
EXECUTE FUNCTION trigger_set_timestamp();