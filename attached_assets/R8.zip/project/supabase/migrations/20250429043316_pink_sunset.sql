/*
  # Fix permission issues with award_templates table

  1. Changes
    - Drop existing RLS policies for award_templates
    - Create new RLS policies that allow both authenticated and anon users to read award templates
    - Add policy for service_role to have full access

  2. Purpose
    - Fix permission issues when accessing award templates from the frontend
    - Ensure both authenticated and anonymous users can read award data
*/

-- First, check if RLS is enabled
ALTER TABLE public.award_templates ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  IF EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'award_templates' AND schemaname = 'public'
  ) THEN
    DROP POLICY IF EXISTS "Anyone can view award templates" ON public.award_templates;
    DROP POLICY IF EXISTS "Service role can manage award templates" ON public.award_templates;
    DROP POLICY IF EXISTS "Anon can view award templates" ON public.award_templates;
  END IF;
END $$;

-- Create policy for authenticated users to read award templates
CREATE POLICY "Authenticated users can view award templates"
  ON public.award_templates
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policy for anonymous users to read award templates
CREATE POLICY "Anonymous users can view award templates"
  ON public.award_templates
  FOR SELECT
  TO anon
  USING (true);

-- Create policy for service role to have full access
CREATE POLICY "Service role can manage award templates"
  ON public.award_templates
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create policy to allow super admins to manage all award templates
CREATE POLICY "Super admin can manage all award templates"
  ON public.award_templates
  FOR ALL
  USING (auth.uid() = '9600a18c-c8e3-44ef-83ad-99ede9268e77'::uuid)
  WITH CHECK (auth.uid() = '9600a18c-c8e3-44ef-83ad-99ede9268e77'::uuid);