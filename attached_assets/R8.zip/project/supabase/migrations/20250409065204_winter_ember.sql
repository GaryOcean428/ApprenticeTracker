/*
  # Create Calculation Templates System

  1. New Tables
    - `calculation_templates`
      - `id` (uuid, primary key)
      - `name` (text, template name)
      - `description` (text, optional description)
      - `apprentice_profiles` (jsonb, array of apprentice profile configurations)
      - `user_id` (uuid, optional foreign key to auth.users)
      - `is_public` (boolean, whether template is public)
      - `industry` (text, optional industry category)
      - `tags` (text array, optional categorization tags)
      - `created_at` (timestamp with time zone, creation time)
      - `updated_at` (timestamp with time zone, last update time)
    
  2. Security
    - Enable RLS on `calculation_templates` table
    - Add policy for users to manage their own templates
    - Add policy for anyone to read public templates
*/

CREATE TABLE IF NOT EXISTS calculation_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  apprentice_profiles jsonb NOT NULL DEFAULT '[]'::jsonb,
  user_id uuid REFERENCES auth.users,
  is_public boolean NOT NULL DEFAULT false,
  industry text,
  tags text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE calculation_templates ENABLE ROW LEVEL SECURITY;

-- Create policy for users to manage their own templates
CREATE POLICY "Users can manage their own templates"
  ON calculation_templates
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create policy for anyone to read public templates
CREATE POLICY "Anyone can view public templates"
  ON calculation_templates
  FOR SELECT
  TO authenticated
  USING (is_public = true);

-- Create a trigger to update the updated_at column
CREATE TRIGGER set_timestamp
BEFORE UPDATE ON calculation_templates
FOR EACH ROW
EXECUTE FUNCTION trigger_set_timestamp();

-- Insert some example templates
INSERT INTO calculation_templates (name, description, apprentice_profiles, is_public, industry, tags) VALUES
('Construction Industry Standard', 'Standard template for construction apprentices with industry-standard settings', 
'[
  {
    "name": "1st Year Construction Apprentice",
    "year": 1,
    "basePayRate": 21.50,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.065,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 950,
      "ppeCost": 450,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 8
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 6
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  },
  {
    "name": "2nd Year Construction Apprentice",
    "year": 2,
    "basePayRate": 25.80,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.065,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 950,
      "ppeCost": 450,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 8
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 6
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  },
  {
    "name": "3rd Year Construction Apprentice",
    "year": 3,
    "basePayRate": 30.10,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.065,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 950,
      "ppeCost": 450,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 8
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 5
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  },
  {
    "name": "4th Year Construction Apprentice",
    "year": 4,
    "basePayRate": 34.40,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.065,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 950,
      "ppeCost": 450,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 8
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 4
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  }
]'::jsonb, true, 'Construction', ARRAY['construction', 'standard']),

('Electrical Industry Standard', 'Standard template for electrical apprentices with industry-standard settings', 
'[
  {
    "name": "1st Year Electrical Apprentice",
    "year": 1,
    "basePayRate": 23.10,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.052,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 1100,
      "ppeCost": 380,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 3
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 6
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  },
  {
    "name": "2nd Year Electrical Apprentice",
    "year": 2,
    "basePayRate": 27.70,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.052,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 1100,
      "ppeCost": 380,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 3
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 6
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  },
  {
    "name": "3rd Year Electrical Apprentice",
    "year": 3,
    "basePayRate": 32.35,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.052,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 1100,
      "ppeCost": 380,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 3
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 5
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  },
  {
    "name": "4th Year Electrical Apprentice",
    "year": 4,
    "basePayRate": 36.95,
    "customSettings": false,
    "costConfig": {
      "superRate": 0.115,
      "wcRate": 0.052,
      "payrollTaxRate": 0.0485,
      "leaveLoading": 0.175,
      "studyCost": 1100,
      "ppeCost": 380,
      "adminRate": 0.17,
      "defaultMargin": 0.15,
      "adverseWeatherDays": 3
    },
    "workConfig": {
      "hoursPerDay": 7.6,
      "daysPerWeek": 5,
      "weeksPerYear": 52,
      "annualLeaveDays": 20,
      "publicHolidays": 10,
      "sickLeaveDays": 10,
      "trainingWeeks": 4
    },
    "billableOptions": {
      "includeAnnualLeave": false,
      "includePublicHolidays": false,
      "includeSickLeave": false,
      "includeTrainingTime": false,
      "includeAdverseWeather": false
    }
  }
]'::jsonb, true, 'Electrical', ARRAY['electrical', 'standard']);