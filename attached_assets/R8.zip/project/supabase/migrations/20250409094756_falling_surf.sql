/*
  # Empty migration - content already applied

  This migration file is intentionally empty because its content has already
  been applied to the database in a previous migration. The schema_migrations_pkey
  constraint violation indicated that this version (20250409094712) was already
  applied.

  The original content was related to custom pay rates and has been consolidated
  with migration 20250409091844_green_brook.sql.
  
  This file exists to maintain the migration sequence without causing errors.
*/

-- No operations needed - already applied in previous migrations