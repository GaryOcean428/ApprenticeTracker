/*
  # Create award_templates table for application use

  1. New Tables
    - `award_templates` (instead of conflicting with existing awards table)
      - `id` (uuid, primary key)
      - `code` (text, unique)
      - `name` (text)
      - `rates` (jsonb)
      - `industry` (text)
      - `updated_at` (timestamp)
  2. Security
    - Enable RLS on `award_templates` table
    - Add policy for authenticated users to read award templates
*/

-- Create a new table that doesn't conflict with the existing awards table
CREATE TABLE IF NOT EXISTS award_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  rates jsonb NOT NULL DEFAULT '{
    "year1": 0,
    "year2": 0,
    "year3": 0,
    "year4": 0,
    "qualified": 0
  }'::jsonb,
  industry text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE award_templates ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read award templates
CREATE POLICY "Anyone can view award templates"
  ON award_templates
  FOR SELECT
  TO authenticated
  USING (true);

-- Add award_template_id column to apprentice_profiles table if it doesn't exist already
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'apprentice_profiles' AND column_name = 'award_template_id'
  ) THEN
    ALTER TABLE apprentice_profiles ADD COLUMN award_template_id uuid;
    ALTER TABLE apprentice_profiles 
    ADD CONSTRAINT fk_award_template_id 
    FOREIGN KEY (award_template_id) 
    REFERENCES award_templates(id);
  END IF;
END $$;

-- Insert some example award templates
INSERT INTO award_templates (code, name, rates, industry) VALUES
('MA000020', 'Building and Construction Award', '{
  "year1": 21.50,
  "year2": 25.80,
  "year3": 30.10,
  "year4": 34.40,
  "qualified": 43.00
}'::jsonb, 'Construction'),
('MA000036', 'Plumbing and Fire Sprinklers Award', '{
  "year1": 22.70,
  "year2": 27.25,
  "year3": 31.80,
  "year4": 36.35,
  "qualified": 45.40
}'::jsonb, 'Plumbing'),
('MA000025', 'Electrical Award', '{
  "year1": 23.10,
  "year2": 27.70,
  "year3": 32.35,
  "year4": 36.95,
  "qualified": 46.20
}'::jsonb, 'Electrical');