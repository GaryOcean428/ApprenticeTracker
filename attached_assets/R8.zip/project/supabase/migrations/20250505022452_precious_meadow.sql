/*
  # Create and configure API keys table

  1. New Tables
    - `api_keys` - Secure storage for API keys used by the application
      - `id` (uuid, primary key)
      - `key_name` (text, unique identifier for the API key)
      - `key_value` (text, the actual API key value)
      - `created_at` (timestamp with time zone)
      - `updated_at` (timestamp with time zone)
      
  2. Security
    - Enable row level security on `api_keys` table
    - Create policies for service_role, authenticated, and anon access
    
  3. Data
    - Insert the Fair Work API key for the application to use
*/

-- Create the api_keys table if it doesn't exist
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name text UNIQUE NOT NULL,
  key_value text NOT NULL,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Add RLS and policies
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid duplication errors
DROP POLICY IF EXISTS "api_keys_service_role_all" ON api_keys;
DROP POLICY IF EXISTS "api_keys_service_role_all_v3" ON api_keys;
DROP POLICY IF EXISTS "api_keys_auth_read" ON api_keys;
DROP POLICY IF EXISTS "api_keys_anon_read" ON api_keys;

-- Service role can do anything with the table
CREATE POLICY "api_keys_service_role_all" ON api_keys
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Authenticated users can read specific keys
CREATE POLICY "api_keys_auth_read" ON api_keys
  FOR SELECT
  TO authenticated
  USING (key_name = 'FAIRWORK_API_KEY');

-- Anonymous users can read specific keys
CREATE POLICY "api_keys_anon_read" ON api_keys
  FOR SELECT
  TO anon
  USING (key_name = 'FAIRWORK_API_KEY');

-- Insert the Fair Work API key for development
-- In production, you would replace this with your actual API key
INSERT INTO api_keys (key_name, key_value)
VALUES 
  ('FAIRWORK_API_KEY', '270281931d6941f6a4738f6a8123ae47')
ON CONFLICT (key_name) 
DO UPDATE SET key_value = EXCLUDED.key_value, updated_at = now();

-- Add comments for documentation
COMMENT ON TABLE api_keys IS 'Secure storage for API keys used by the application';
COMMENT ON COLUMN api_keys.key_name IS 'Unique identifier for the API key (e.g., FAIRWORK_API_KEY)';
COMMENT ON COLUMN api_keys.key_value IS 'The actual API key value';