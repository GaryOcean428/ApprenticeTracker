/*
  # Fix award_templates permissions

  1. Changes
     - Enable row level security on award_templates table
     - Add policies for authenticated users to read award templates
     - Add policies for service role to manage award templates
     - Add policies for anonymous users to view award templates
*/

-- First ensure RLS is enabled on the award_templates table
ALTER TABLE IF EXISTS public.award_templates ENABLE ROW LEVEL SECURITY;

-- Remove any conflicting policies
DROP POLICY IF EXISTS "Anyone can view award templates" ON public.award_templates;
DROP POLICY IF EXISTS "Authenticated users can view award templates" ON public.award_templates;
DROP POLICY IF EXISTS "Anonymous users can view award templates" ON public.award_templates;
DROP POLICY IF EXISTS "Service role can manage award templates" ON public.award_templates;

-- Create policy for anonymous users to view award templates
CREATE POLICY "Anonymous users can view award templates" 
ON public.award_templates
FOR SELECT
TO anon
USING (true);

-- Create policy for authenticated users to view award templates
CREATE POLICY "Authenticated users can view award templates" 
ON public.award_templates
FOR SELECT
TO authenticated
USING (true);

-- Create policy for service role to manage all operations on award templates
CREATE POLICY "Service role can manage award templates" 
ON public.award_templates
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);