/*
  # Create Custom Pay Rates Table

  1. New Tables
    - `custom_pay_rates`
      - `id` (uuid, primary key)
      - `name` (text)
      - `year1_rate` (numeric)
      - `year2_rate` (numeric) 
      - `year3_rate` (numeric)
      - `year4_rate` (numeric)
      - `industry` (text, optional)
      - `user_id` (uuid, optional)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
  2. Security
    - Enable RLS on `custom_pay_rates` table
    - Add policy for users to manage their own presets
    - Add policy for users to view public presets
*/

CREATE TABLE IF NOT EXISTS custom_pay_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  year1_rate numeric(10,2) NOT NULL,
  year2_rate numeric(10,2) NOT NULL,
  year3_rate numeric(10,2) NOT NULL,
  year4_rate numeric(10,2) NOT NULL,
  industry text,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  is_public boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE custom_pay_rates ENABLE ROW LEVEL SECURITY;

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION update_custom_pay_rates_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_custom_pay_rates_updated_at
BEFORE UPDATE ON custom_pay_rates
FOR EACH ROW EXECUTE FUNCTION update_custom_pay_rates_updated_at();

-- Users can manage their own pay rate presets
CREATE POLICY "Users can manage their own pay rate presets"
ON custom_pay_rates
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Users can view public pay rate presets
CREATE POLICY "Users can view public pay rate presets"
ON custom_pay_rates
FOR SELECT
TO authenticated
USING (is_public = true);

-- Insert some default pay rate presets for testing
INSERT INTO custom_pay_rates (name, year1_rate, year2_rate, year3_rate, year4_rate, industry, is_public)
VALUES 
('Construction Industry Standard', 21.50, 25.75, 29.90, 34.25, 'Construction', true),
('Electrical Apprentice Rates', 22.25, 26.50, 31.75, 36.00, 'Trades', true),
('Plumbing Apprentice Rates', 21.75, 26.00, 30.50, 35.50, 'Trades', true);