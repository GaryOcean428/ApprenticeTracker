import { createClient } from "npm:@supabase/supabase-js@2.39.7";
import { cron } from "npm:@js-cron/parser@1.0.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

// API Configuration for Fair Work Commission
const API_BASE_URL = 'https://api.fwc.gov.au/api/v1';

// Fallback data by year for testing
const FALLBACK_DATA_BY_YEAR: Record<number, any[]> = {
  2025: [
    {
      award_fixed_id: 1,
      code: "MA000003",
      name: "Building and Construction General On-site Award",
      published_year: 2025,
      rates: [
        { year: 1, hourlyRate: 23.47 },
        { year: 2, hourlyRate: 28.17 },
        { year: 3, hourlyRate: 32.86 },
        { year: 4, hourlyRate: 37.56 }
      ]
    },
    {
      award_fixed_id: 2,
      code: "MA000020",
      name: "Building and Construction General Award",
      published_year: 2025,
      rates: [
        { year: 1, hourlyRate: 23.47 },
        { year: 2, hourlyRate: 28.17 },
        { year: 3, hourlyRate: 32.86 },
        { year: 4, hourlyRate: 37.56 }
      ]
    }
  ],
  2024: [
    {
      award_fixed_id: 1,
      code: "MA000003",
      name: "Building and Construction General On-site Award",
      published_year: 2024,
      rates: [
        { year: 1, hourlyRate: 22.28 },
        { year: 2, hourlyRate: 26.74 },
        { year: 3, hourlyRate: 31.20 },
        { year: 4, hourlyRate: 35.65 }
      ]
    }
  ]
};

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 204,
    });
  }

  try {
    // Log request information
    console.log(`Request method: ${req.method}`);
    console.log(`Request URL: ${req.url}`);
    const headers = Object.fromEntries([...req.headers.entries()]);
    console.log('Request headers:', JSON.stringify({
      ...headers,
      Authorization: headers.Authorization ? 'Bearer [REDACTED]' : undefined
    }));

    // Parse request body if present
    let requestBody = null;
    if (req.method === 'POST') {
      try {
        requestBody = await req.json();
        console.log('Request body:', JSON.stringify(requestBody));
      } catch (e) {
        console.warn('Could not parse request body as JSON:', e);
      }
    }

    // Create a Supabase client with the Auth context of the logged in user
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    // Get the Fair Work API key from the database or environment
    const { data: apiKeyData, error: apiKeyError } = await supabaseClient
      .from("api_keys")
      .select("key_value")
      .eq("service_name", "fairwork")
      .eq("is_active", true)
      .single();

    if (apiKeyError) {
      console.error("Error fetching API key:", apiKeyError);
      
      // Check if we have an API key in environment variables
      const fallbackKey = Deno.env.get("FAIRWORK_API_KEY");
      if (!fallbackKey) {
        throw new Error("Fair Work API key not found in database or environment variables");
      }
      
      console.log("Using API key from environment variable");
    }

    const fairWorkApiKey = apiKeyData?.key_value || Deno.env.get("FAIRWORK_API_KEY");
    if (!fairWorkApiKey) {
      throw new Error("Fair Work API key not found");
    }
    
    console.log("API Key retrieved successfully");

    // Check if this is a scheduled or manual trigger
    const url = new URL(req.url);
    const isScheduled = url.searchParams.get('scheduled') === 'true';
    const years = requestBody?.years || [new Date().getFullYear()]; // Default to current year

    // If scheduled, check if it's time to run
    if (isScheduled) {
      // Run sync job every Sunday at 1:00 AM
      const cronExpression = "0 1 * * 0";
      const now = new Date();
      
      try {
        const schedule = cron(cronExpression);
        const nextRun = schedule.getNext();
        
        // Get the previous run time (24 hours ago)
        const prevRun = new Date(now);
        prevRun.setDate(prevRun.getDate() - 1);
        
        // Check if we should run now (between prev and next scheduled time)
        if (nextRun <= now && now <= schedule.getNext(nextRun)) {
          console.log("Scheduled sync time - executing award rate sync");
        } else {
          // Not time to run yet
          return new Response(JSON.stringify({ 
            message: "Sync skipped - not scheduled time",
            nextScheduledRun: schedule.getNext().toISOString()
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
            status: 200,
          });
        }
      } catch (error) {
        console.error("Error parsing cron expression:", error);
      }
    }

    console.log(`Processing sync for years: ${years.join(', ')}`);

    // For each year, fetch and update award templates
    const results = [];
    for (const year of years) {
      try {
        console.log(`Processing year ${year}`);
        
        // In a production environment, use actual API data
        // For this demo, we'll use fallback data
        const awards = FALLBACK_DATA_BY_YEAR[year] || [];
        
        if (awards.length === 0) {
          console.warn(`No awards found for year ${year}`);
          results.push({
            year,
            success: false,
            error: 'No awards found for this year'
          });
          continue;
        }
        
        console.log(`Found ${awards.length} awards for year ${year}`);
        
        for (const award of awards) {
          console.log(`Processing award ${award.code} - ${award.name}`);
          
          // Prepare the award data in our format
          const templateData = {
            code: award.code,
            name: award.name,
            calendar_year: year,
            rates: {
              year1: award.rates.find((r: any) => r.year === 1)?.hourlyRate || 0,
              year2: award.rates.find((r: any) => r.year === 2)?.hourlyRate || 0,
              year3: award.rates.find((r: any) => r.year === 3)?.hourlyRate || 0,
              year4: award.rates.find((r: any) => r.year === 4)?.hourlyRate || 0,
              qualified: 0 // Default value
            },
            updated_at: new Date().toISOString()
          };
          
          console.log(`Award template data:`, JSON.stringify(templateData));
          
          // Insert or update the award template
          const { data, error } = await supabaseClient
            .from('award_templates')
            .upsert({
              ...templateData,
              // Use the combination of code and calendar_year as the key
              id: awards.some((a: any) => a.code === award.code && a.calendar_year === year) 
                ? undefined // Let Supabase generate a new ID
                : undefined // Let Supabase generate a new ID
            })
            .select();
            
          if (error) {
            console.error(`Error syncing award ${award.code} for year ${year}:`, error);
            results.push({
              award: award.code,
              year,
              success: false,
              error: error.message
            });
          } else {
            console.log(`Successfully synced award ${award.code} for year ${year}`);
            results.push({
              award: award.code,
              year,
              success: true,
              data: data[0].id
            });
          }
        }
        
      } catch (error) {
        console.error(`Error processing year ${year}:`, error);
        results.push({
          year,
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    // Format financial years for response
    const financialYears = years.map(calendarYear => {
      const financialYear = calendarYear - 1;
      return `${financialYear}-${calendarYear}`;
    });

    // Return the sync results
    return new Response(JSON.stringify({
      message: "Award rates sync completed",
      results,
      financial_years: financialYears,
      timestamp: new Date().toISOString(),
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 200,
    });
  } catch (error) {
    console.error("Error in sync-award-rates function:", error);
    
    return new Response(JSON.stringify({ 
      error: "Failed to sync award rates",
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
      documentation: "/docs/fairwork-api.md"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 500,
    });
  }
});