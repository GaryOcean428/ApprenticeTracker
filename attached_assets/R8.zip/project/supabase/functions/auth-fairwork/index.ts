import { createClient } from "npm:@supabase/supabase-js@2.39.7";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

// API Configuration for Fair Work Commission
const API_BASE_URL = 'https://api.fwc.gov.au/api/v1';

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 204,
    });
  }

  try {
    // Create a Supabase client with the Auth context
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    // Get JWT from request
    const authHeader = req.headers.get('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new Error('Missing or invalid authorization header');
    }
    
    const token = authHeader.split(' ')[1];
    
    // Verify the JWT and get the user
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    if (authError) {
      throw new Error(`Authentication error: ${authError.message}`);
    }
    
    if (!user) {
      throw new Error('User not found');
    }
    
    // Parse URL to get endpoint and year
    const url = new URL(req.url);
    const endpoint = url.searchParams.get('endpoint');
    const year = url.searchParams.get('year');
    
    if (!endpoint) {
      throw new Error('Missing endpoint parameter');
    }
    
    // Get the API key from environment variables or database
    let apiKey = Deno.env.get("FAIRWORK_API_KEY");
    if (!apiKey) {
      // Check if API key exists in Supabase
      const { data: apiKeyData, error: apiKeyError } = await supabaseClient
        .from("api_keys")
        .select("key_value")
        .eq("key_name", "FAIRWORK_API_KEY")
        .single();
      
      if (apiKeyError || !apiKeyData) {
        console.error("Error fetching API key:", apiKeyError);
        throw new Error('API key not available from any source');
      }
      
      apiKey = apiKeyData.key_value;
    }
    
    // Log the request details for debugging (without exposing the API key)
    console.log(`Making request to Fair Work API: ${API_BASE_URL}${endpoint}${year ? ` for year ${year}` : ''}`);
    
    // Modify endpoint to include year if available
    let apiEndpoint = endpoint;
    if (year && !endpoint.includes('year=')) {
      apiEndpoint += endpoint.includes('?') ? `&year=${year}` : `?year=${year}`;
    }
    
    // Make the request to the Fair Work API
    const apiUrl = `${API_BASE_URL}${apiEndpoint}`;
    console.log(`API URL: ${apiUrl}`);
    
    // Add detailed request logging
    const requestHeaders = {
      'Ocp-Apim-Subscription-Key': apiKey,
      'Accept': 'application/json'
    };
    console.log('Request headers:', JSON.stringify({
      Accept: requestHeaders.Accept,
      // Don't log the actual API key
      'Ocp-Apim-Subscription-Key': 'REDACTED'
    }));
    
    try {
      const response = await fetch(apiUrl, {
        headers: requestHeaders,
        // Add timeout to prevent hanging requests
        signal: AbortSignal.timeout(15000) // 15 seconds timeout
      });
      
      // Log response details
      console.log(`Response status: ${response.status} ${response.statusText}`);
      console.log(`Response headers:`, Object.fromEntries([...response.headers.entries()]));
      
      if (!response.ok) {
        const errorText = await response.text().catch(() => 'No error details available');
        console.error(`API request failed: ${response.status} ${response.statusText}`, errorText);
        throw new Error(`API request failed: ${response.status} ${response.statusText}\n${errorText}`);
      }
      
      // Get data from response
      const data = await response.json();
      console.log(`Data received for endpoint ${endpoint}${year ? ` and year ${year}` : ''}`);
      
      // Return the data
      return new Response(JSON.stringify({ data, year: year || 'current' }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      });
    } catch (fetchError) {
      console.error(`Fetch error: ${fetchError instanceof Error ? fetchError.message : 'Unknown error'}`);
      throw new Error(`Fetch error: ${fetchError instanceof Error ? fetchError.message : 'Unknown error'}`);
    }
  } catch (error) {
    console.error("Error in auth-fairwork function:", error);
    
    // Include more detailed error information in response
    return new Response(JSON.stringify({ 
      error: "Failed to fetch data from Fair Work API",
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
      // Include docs link to help with troubleshooting
      documentation: "/docs/fairwork-api.md"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 500,
    });
  }
});