import { createClient } from "npm:@supabase/supabase-js@2.39.7";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 204,
    });
  }

  try {
    console.log("Received request for Fair Work API key");
    
    // Create a Supabase client with the Auth context of the logged in user
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    // Get the Fair Work API key from the database
    const { data, error } = await supabaseClient
      .from("api_keys")
      .select("key_value")
      .eq("key_name", "FAIRWORK_API_KEY")
      .single();

    if (error) {
      console.error("Database error:", error);
      
      // Fallback to environment variable if database access fails
      const fallbackKey = Deno.env.get("FAIRWORK_API_KEY");
      if (fallbackKey) {
        console.log("Using API key from environment variable");
        return new Response(JSON.stringify({ key: fallbackKey }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
          status: 200,
        });
      }
      
      if (error.message.includes("permission denied")) {
        console.log("Permission denied for api_keys table, using environment variable");
        const envKey = Deno.env.get("FAIRWORK_API_KEY");
        if (!envKey) {
          throw new Error("No API key available in environment variables after permission denied");
        }
        
        return new Response(JSON.stringify({ key: envKey }), {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
          status: 200,
        });
      }
      
      throw error;
    }

    if (!data || !data.key_value) {
      // Try using environment variable as fallback
      const envKey = Deno.env.get("FAIRWORK_API_KEY");
      if (!envKey) {
        throw new Error("API key not found in database or environment variables");
      }
      
      console.log("API key not found in database, using environment variable");
      return new Response(JSON.stringify({ key: envKey }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      });
    }

    console.log("API key retrieved successfully");
    
    // Return the API key with appropriate headers
    return new Response(JSON.stringify({ key: data.key_value }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 200,
    });
  } catch (error) {
    console.error("Error fetching Fair Work API key:", error);
    
    // Return a fallback key from environment variable
    const fallbackKey = Deno.env.get("FAIRWORK_API_KEY");
    if (fallbackKey) {
      console.log("Error occurred but using fallback key from environment");
      return new Response(JSON.stringify({ key: fallbackKey }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
        status: 200,
      });
    }
    
    return new Response(JSON.stringify({ 
      error: "Failed to fetch API key",
      message: error instanceof Error ? error.message : "Unknown error"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 500,
    });
  }
});