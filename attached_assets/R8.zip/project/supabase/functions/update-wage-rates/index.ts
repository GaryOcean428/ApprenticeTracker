import { createClient } from "npm:@supabase/supabase-js@2.39.7";
import { cron } from "npm:@js-cron/parser@1.0.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

// API Configuration for Fair Work Commission
const API_BASE_URL = 'https://api.fwc.gov.au/api/v1';

// Fallback data for different financial years (used for testing)
const FALLBACK_DATA_BY_FY: Record<number, any[]> = {
  2024: [ // FY2024-25
    {
      award_fixed_id: 1,
      code: "MA000020",
      name: "Building and Construction General Award",
      published_year: 2025, // Calendar year after FY starts
      financial_year: 2024,
      rates: [
        { year: 1, hourlyRate: 23.47 },
        { year: 2, hourlyRate: 28.17 },
        { year: 3, hourlyRate: 32.86 },
        { year: 4, hourlyRate: 37.56 }
      ]
    },
    {
      award_fixed_id: 3,
      code: "MA000036",
      name: "Plumbing and Fire Sprinklers Award",
      published_year: 2025,
      financial_year: 2024,
      rates: [
        { year: 1, hourlyRate: 24.38 },
        { year: 2, hourlyRate: 28.93 },
        { year: 3, hourlyRate: 33.95 },
        { year: 4, hourlyRate: 39.01 }
      ]
    }
  ],
  2023: [ // FY2023-24
    {
      award_fixed_id: 1,
      code: "MA000020",
      name: "Building and Construction General Award",
      published_year: 2024,
      financial_year: 2023,
      rates: [
        { year: 1, hourlyRate: 22.28 },
        { year: 2, hourlyRate: 26.74 },
        { year: 3, hourlyRate: 31.20 },
        { year: 4, hourlyRate: 35.65 }
      ]
    }
  ]
};

/**
 * Get the current financial year (July-June)
 */
function getCurrentFinancialYear(): number {
  const now = new Date();
  const currentMonth = now.getMonth(); // 0-11 (January is 0)
  const currentYear = now.getFullYear();
  
  // If we're in July-December, FY is the current year
  // If we're in January-June, FY is the previous year
  return currentMonth >= 6 ? currentYear : currentYear - 1;
}

// Scheduled to run on July 1st each year (using cron syntax)
Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 204,
    });
  }

  try {
    // Create a Supabase client with the service role key
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    );

    // Get the Fair Work API key from the database or environment
    const { data: apiKeyData, error: apiKeyError } = await supabaseClient
      .from("api_keys")
      .select("key_value")
      .eq("service_name", "fairwork")
      .eq("is_active", true)
      .single();

    if (apiKeyError) {
      console.warn("Error fetching API key from database:", apiKeyError);
      // Continue with env var fallback
    }

    const fairWorkApiKey = apiKeyData?.key_value || Deno.env.get("FAIRWORK_API_KEY");
    if (!fairWorkApiKey) {
      throw new Error("Fair Work API key not found");
    }

    // Check if this is a scheduled or manual trigger
    const url = new URL(req.url);
    const isManual = url.searchParams.get('manual') === 'true';
    const specificFY = url.searchParams.get('fy') ? parseInt(url.searchParams.get('fy')!) : null;
    
    // If scheduled, check if it's time to run
    if (!isManual) {
      // Run sync job on July 1st at 1:00 AM
      const cronExpression = "0 1 1 7 *";  // minute hour day month day-of-week
      const now = new Date();
      
      try {
        const schedule = cron(cronExpression);
        const nextRun = schedule.getNext();
        
        // Get the previous run time (24 hours ago)
        const prevRun = new Date(now);
        prevRun.setDate(prevRun.getDate() - 1);
        
        // Check if we should run now
        const shouldRunToday = now.getDate() === 1 && now.getMonth() === 6; // July 1st
        
        if (!shouldRunToday && !isManual) {
          return new Response(JSON.stringify({ 
            message: "Not July 1st - skipping automatic update",
            nextScheduledRun: new Date(now.getFullYear(), 6, 1, 1, 0, 0).toISOString() // Next July 1st
          }), {
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
            status: 200,
          });
        }
      } catch (error) {
        console.error("Error parsing cron expression:", error);
      }
    }

    // Determine financial years to update
    let financialYears: number[] = [];
    
    if (specificFY !== null) {
      // If a specific FY is requested
      financialYears = [specificFY];
    } else {
      // Default: Update current FY (which just started on July 1st)
      financialYears = [getCurrentFinancialYear()];
    }

    // For each financial year, fetch and update award templates
    const results = [];
    for (const financialYear of financialYears) {
      try {
        // Calendar year for the rates (FY + 1)
        const calendarYear = financialYear + 1;
        
        // Get the awards and rates for this financial year from our fallback data
        const awards = FALLBACK_DATA_BY_FY[financialYear] || [];
        
        if (awards.length === 0) {
          console.warn(`No awards found for FY${financialYear}-${financialYear+1}`);
          results.push({
            financial_year: financialYear,
            success: false,
            error: 'No awards found for this financial year'
          });
          continue;
        }
        
        for (const award of awards) {
          // Group rates by apprentice year
          const ratesByYear: Record<number, number> = {};
          award.rates.forEach((rate: any) => {
            if (rate.year && rate.year >= 1 && rate.year <= 4) {
              ratesByYear[rate.year] = rate.hourlyRate;
            }
          });
          
          // Skip if no rates found
          if (Object.keys(ratesByYear).length === 0) {
            console.warn(`No rates found for award ${award.code}`);
            continue;
          }
          
          // Create or update award template in Supabase
          const { data, error } = await supabaseClient
            .from('award_templates')
            .upsert({
              code: award.code,
              name: award.name,
              calendar_year: calendarYear,
              financial_year: financialYear,
              rates: {
                year1: ratesByYear[1] || 0,
                year2: ratesByYear[2] || 0,
                year3: ratesByYear[3] || 0,
                year4: ratesByYear[4] || 0,
                qualified: 0 // No qualified rate from apprentice rates
              },
              updated_at: new Date().toISOString()
            })
            .select();
          
          if (error) {
            console.error(`Error upserting award ${award.code} for FY ${financialYear}-${financialYear+1}:`, error);
            results.push({
              award: award.code,
              financial_year: financialYear,
              success: false,
              error: error.message
            });
          } else {
            console.log(`Successfully updated award ${award.code} for FY ${financialYear}-${financialYear+1}`);
            results.push({
              award: award.code,
              financial_year: financialYear,
              success: true,
            });
          }
        }
        
        // Update the last_updated record to indicate successful sync
        await supabaseClient
          .from('system_settings')
          .upsert({
            key: 'award_rates_last_updated',
            value: new Date().toISOString(),
            updated_by: isManual ? 'manual_trigger' : 'scheduled_task'
          });
        
        // Send notifications to users who have opted in
        if (!isManual) {
          // In production, this would send notifications to users
          console.log(`Notifications would be sent to users about FY${financialYear}-${financialYear+1} wage updates`);
        }
        
      } catch (error) {
        console.error(`Error processing FY ${financialYear}-${financialYear+1}:`, error);
        results.push({
          financial_year: financialYear,
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    // Return the update results
    return new Response(JSON.stringify({
      message: isManual ? "Manual wage rate update completed" : "Scheduled wage rate update completed",
      financial_years: financialYears.map(fy => `${fy}-${fy+1}`),
      results,
      timestamp: new Date().toISOString(),
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 200,
    });
  } catch (error) {
    console.error("Error in update-wage-rates function:", error);
    
    return new Response(JSON.stringify({ 
      error: "Failed to update wage rates",
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date().toISOString(),
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
      },
      status: 500,
    });
  }
});